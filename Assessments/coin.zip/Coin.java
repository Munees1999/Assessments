package com.assesment;

public class Coin {
	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			if (Math.random() < 0.5) {

				System.out.println("heads");

			} else {
				System.out.println("tails");
			}

		}
	}
}