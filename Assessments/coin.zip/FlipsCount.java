package com.assesment;

import java.util.Scanner;

public class FlipsCount {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the count of Coin flip ");
		int no = sc.nextInt();
		
		for (int i = 0; i < no; i++) {
			
			if (Math.random() < 0.5) {
				System.out.println("Heads");
			} else {
				System.out.println("Tails");
			}
		}
	}

}
