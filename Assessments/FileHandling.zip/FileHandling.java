package com.assesment;

import java.io.*;

public class FileHandling {
	public static void main(String[] args) {
		try {
			File folder = new File("File");
			if (!folder.exists()) {
				folder.mkdir();
			}

			FileWriter fw = new FileWriter("File/Greating.txt");
			BufferedWriter bw = new BufferedWriter(fw, 2000);
			bw.write("Hii All...");
			bw.close();
			// fw.close();

			System.out.println("Data saved");

			FileReader fr = new FileReader("File/Greating.txt");
			BufferedReader br = new BufferedReader(fr);
			String st = null;
			while ((st = br.readLine()) != null) {
				System.out.println(st);

				if (st.contains("error") || st.contains("warn") || st.contains("fatal")) {

					FileWriter fwr = new FileWriter("File/Greating1.txt", true);
					fwr.write(st);
					fwr.close();

					System.out.println("copied success");
				} else {

					br.close();

					System.out.println("Not Copied");

				}

			}

		} catch (IOException e1) {
			e1.printStackTrace();

		}
	}

}
