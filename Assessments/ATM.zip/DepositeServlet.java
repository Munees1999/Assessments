package com.vastpro.in.task;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DepositeServlet
 */
@WebServlet("/DepositeServlet")
public class DepositeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	double amount=50000;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepositeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h3>Deposite</h3>");
		out.println("<body><form><table><tr><td>amount:</td></tr><tr><td><input type='number' name='deposite' placeholder='Enter the amount'</td></tr>"
				+ "<tr><td><input type='submit' value='go'</td></tr></table></form></body>");
		double deposite1=Double.parseDouble(request.getParameter("deposite"));
		if(deposite1!=0) {
			double balance=amount+deposite1;
			out.println("balance ="+balance);
		}
		else {
			out.println("please enter the number");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
