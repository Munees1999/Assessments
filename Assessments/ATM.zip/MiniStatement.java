package com.vastpro.in.task

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MiniStatement
 * 
 */
@WebServlet("/MiniStatement")

public class MiniStatement extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HashMap<String, Integer> hm = new HashMap<String, Integer>();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MiniStatement() {
        super();
        // TODO Auto-generated constructor stub
        hm.put("1234567899878564", 1234);
        hm.put("9842183051984216", 4562);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("<h1>MiniStatement<h1>");
        pw.println("<body><form><table><tr><td>card number : </td><td><input type ='text' name = 'card' placeholder = 'enter your card number'</td></tr>"
        		+"<tr><td>pin number : </td><td><input type ='text' name = 'pin' placeholder = 'enter your pin number'</td>"
        		+ "</tr><tr><td><input type = 'submit' value = 'ok'</td></tr></table></form></body>");
        
       String card1 = request.getParameter("card");
       int pin1 = Integer.parseInt(request.getParameter("pin"));
     //  pw.println(card1);
       
       for(Map.Entry m : hm.entrySet()) {
    	   
    	   int pin2 = (int) m.getValue();
    	   if(card1.equals(m.getKey()) && (pin1 == pin2)) {
    		   
    		   pw.println("Ac/no - 1149115000096744");
    		   pw.println(" Name - Balamurugan");
    		   pw.println(" withdraw - 20000");
    		   pw.println(" Balance - 30000");break; 
    		   
    	   }
    	   else {
    		   pw.println("please enter valid card number"); break;
    	   }
    		   
    		
    	   }
        
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
