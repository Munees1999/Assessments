package com.vastpro.in.task

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BalanceServlet
 */
@WebServlet("/BalanceServlet")
public class BalanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	HashMap<String, Integer> hm = new HashMap<String, Integer>();
    public BalanceServlet() {
    	
    	
    	hm.put("1234567899876543",10000);
    	
    	hm.put("9842183051984216", 40000);
     
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        pw.println("<h1>Balance<h1>");
        pw.println("<body><form><table><tr><td>card number : </td><td><input type ='text' name = 'balance' placeholder = 'enter the card number'</td>"
        		+ "</tr><tr><td><input type = 'submit' value = 'ok'</td></tr></table></form></body>");
       
        
        String card = request.getParameter("balance");
       
        
        for(Map.Entry m : hm.entrySet()) {
        	
        	if(card.equals(m.getKey())) {
        		pw.println("your balance - "+m.getValue());break;
        	}
        	else {
        		
        		pw.println("please enter valid card number");break;
        	}
        	
        }

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
