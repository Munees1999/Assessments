package com.assesment;

import java.util.Scanner;

public class CircleTest {
	public static void main(String[] args) {
		double sum=0;

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Circle numbers");
		int circle = sc.nextInt();

		for (int i = 0; i < circle; i++) {
			System.out.println("Enter the radius value");

			int rad = sc.nextInt();

			Circle cir = new Circle(rad);
			cir.getArea();
			cir.printInfo();

		}
		int[] arr=new int[100];
		for(int i=0;i<arr.length;i++) {
			
			arr[i]=(int)(Math.random()*10);
			Circle circ=new Circle(arr[i]);
			sum=sum+circ.getArea();
			
			
		}
		System.out.println("total radius of the circle is"+sum);
		
	}

}
