package com.assesment;

public class Circle {
	 static double pi=3.14;
	static int radius;
	double Area;
	public Circle(int radius) {
		
		this.radius=radius;
		
	}
	public void getArea() {
		Area=pi*radius*radius;
	}
	 public  void printInfo() {
		 System.out.println("radius value ="+radius);
		 System.out.println("Area = "+Area);
		 
	 }

}
